#ifndef InitCaller_h
#define InitCaller_h

extern void _callFunc();

#endif