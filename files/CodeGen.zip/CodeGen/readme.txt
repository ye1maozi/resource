两种方式可以生产垃圾代码：
1.导入ECLIPSE工程，运行；
2.终端执行
JAVAC XXX.JAVA
JAVA XXX
第二步需要指定包名才能正常运行；


在Generator.java文件里main函数里指定输出路径和生成文件的数量；

代码生成后，工程里面要引用。方法如下#import "InitCaller.h"……if(someCondition == TRUE)    {        _callFunc();    }注意这行代码一定不能被真实调用。只是骗过链接器。即somecondition这个变量永远为false


dll xiaoy